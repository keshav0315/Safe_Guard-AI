﻿from django.apps import AppConfig


class AiDetectionConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'apps.ai_detection'
    verbose_name = 'AI Detection'
